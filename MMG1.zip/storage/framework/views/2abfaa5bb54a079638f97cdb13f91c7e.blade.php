<span class="outline-none inline-flex justify-center items-center group rounded gap-x-1 text-xs font-semibold px-2.5 py-0.5 text-white bg-positive-500 dark:bg-positive-700">
    
    Accepted

    </span>
