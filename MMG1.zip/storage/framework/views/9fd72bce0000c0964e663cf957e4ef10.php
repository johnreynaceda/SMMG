

<div x-data>
    <div class="flex justify-between items-end">
        <div class="flex space-x-3 items-center">
            <?php if (isset($component)) { $__componentOriginal2225aca2c40fa71fe239aabb14054f8e = $component; } ?>
<?php $component = WireUi\View\Components\DatetimePicker::resolve(['label' => 'Date From','withoutTime' => true] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('datetime-picker'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(WireUi\View\Components\DatetimePicker::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['placeholder' => ''.e(now()).'','wire:model' => 'created_from']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2225aca2c40fa71fe239aabb14054f8e)): ?>
<?php $component = $__componentOriginal2225aca2c40fa71fe239aabb14054f8e; ?>
<?php unset($__componentOriginal2225aca2c40fa71fe239aabb14054f8e); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal2225aca2c40fa71fe239aabb14054f8e = $component; } ?>
<?php $component = WireUi\View\Components\DatetimePicker::resolve(['label' => 'Date To','withoutTime' => true] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('datetime-picker'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(WireUi\View\Components\DatetimePicker::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['placeholder' => ''.e(now()).'','wire:model' => 'created_until']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2225aca2c40fa71fe239aabb14054f8e)): ?>
<?php $component = $__componentOriginal2225aca2c40fa71fe239aabb14054f8e; ?>
<?php unset($__componentOriginal2225aca2c40fa71fe239aabb14054f8e); ?>
<?php endif; ?>
        </div>
        <div>
            <?php if (isset($component)) { $__componentOriginal53cf851b4d6af185b0b5e0467ca69b92 = $component; } ?>
<?php $component = WireUi\View\Components\Button::resolve(['label' => 'PRINT','icon' => 'printer'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(WireUi\View\Components\Button::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'font-bold','@click' => 'printOut($refs.printContainer.outerHTML);','dark' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal53cf851b4d6af185b0b5e0467ca69b92)): ?>
<?php $component = $__componentOriginal53cf851b4d6af185b0b5e0467ca69b92; ?>
<?php unset($__componentOriginal53cf851b4d6af185b0b5e0467ca69b92); ?>
<?php endif; ?>
        </div>

    </div>
    <div class="mt-5">
        <div x-ref="printContainer" class="bg-white p-5 rounded-xl">
            <div class="flex space-x-3 items-center">
                <div>
                    <img src="<?php echo e(asset('images/logo.png')); ?>" class="h-12" alt="">
                </div>
                <div>
                    <h1 class="text-xl font-bold text-gray-700">MMG - BULAN</h1>
                    <h1 class="text-md  leading-3 font-bold uppercase text-gray-500">Appointments List</h1>
                </div>
            </div>
            <div class="mt-10">
                <table id="example" class="table-auto" style="width:100%">
                    <thead class="font-normal">
                        <tr>
                            <th class="border-2  text-left px-2 text-sm font-bold text-gray-700 py-2">PATIENT NAME
                            </th>
                            <th class="border-2  text-left px-2 text-sm font-bold text-gray-700 py-2">DOCTOR NAME
                            </th>
                            <th class="border-2  text-left px-2 text-sm font-bold text-gray-700 py-2">CONDITION
                            </th>
                            <th class="border-2  text-left px-2 text-sm font-bold text-gray-700 py-2">ADDRESS</th>

                            <th class="border-2  text-left px-2 text-sm font-bold text-gray-700 py-2">DATE OF
                                APPOINTMENT
                            </th>
                            <th class="border-2  text-left px-2 text-sm font-bold text-gray-700 py-2">
                                STATUS
                            </th>
                            <th class="border-2  text-left px-2 text-sm font-bold text-gray-700 py-2">

                            </th>


                        </tr>
                    </thead>
                    <tbody class="">
                        <?php $__empty_1 = true; $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="border-2 uppercase text-gray-700  px-3 py-1">
                                    <?php echo e($report->user->name); ?>

                                </td>
                                <td class="border-2 uppercase text-gray-700  px-3 py-1">
                                    <?php echo e($report->doctor->user->name); ?>

                                </td>
                                <td class="border-2 uppercase text-gray-700  px-3 py-1">
                                    <?php echo e($report->condition); ?>

                                </td>
                                <td class="border-2  text-gray-700  px-3 py-1">
                                    <?php echo e($report->user->patient_profile->address); ?>

                                </td>
                                <td class="border-2  text-gray-700  px-3 py-1">
                                    <?php echo e(\Carbon\Carbon::parse($report->appointment_date)->format('F d, Y')); ?>

                                </td>
                                <td class="border-2  text-gray-700  px-3 py-1">
                                    <?php switch($report->status):
                                        case ('pending'): ?>
                                            <?php if (isset($component)) { $__componentOriginal3f4792426b7364bb3dac7370e7314380 = $component; } ?>
<?php $component = WireUi\View\Components\Badge::resolve(['label' => 'Pending'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(WireUi\View\Components\Badge::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['warning' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3f4792426b7364bb3dac7370e7314380)): ?>
<?php $component = $__componentOriginal3f4792426b7364bb3dac7370e7314380; ?>
<?php unset($__componentOriginal3f4792426b7364bb3dac7370e7314380); ?>
<?php endif; ?>
                                        <?php break; ?>

                                        <?php case ('accepted'): ?>
                                            <?php if (isset($component)) { $__componentOriginal3f4792426b7364bb3dac7370e7314380 = $component; } ?>
<?php $component = WireUi\View\Components\Badge::resolve(['label' => 'Accepted'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(WireUi\View\Components\Badge::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['positive' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3f4792426b7364bb3dac7370e7314380)): ?>
<?php $component = $__componentOriginal3f4792426b7364bb3dac7370e7314380; ?>
<?php unset($__componentOriginal3f4792426b7364bb3dac7370e7314380); ?>
<?php endif; ?>
                                        <?php break; ?>

                                        <?php case ('declined'): ?>
                                            <?php if (isset($component)) { $__componentOriginal3f4792426b7364bb3dac7370e7314380 = $component; } ?>
<?php $component = WireUi\View\Components\Badge::resolve(['label' => 'Declined'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(WireUi\View\Components\Badge::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['negative' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3f4792426b7364bb3dac7370e7314380)): ?>
<?php $component = $__componentOriginal3f4792426b7364bb3dac7370e7314380; ?>
<?php unset($__componentOriginal3f4792426b7364bb3dac7370e7314380); ?>
<?php endif; ?>
                                        <?php break; ?>

                                        <?php case ('done'): ?>
                                            <?php if (isset($component)) { $__componentOriginal3f4792426b7364bb3dac7370e7314380 = $component; } ?>
<?php $component = WireUi\View\Components\Badge::resolve(['label' => 'Done','outline' => true] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(WireUi\View\Components\Badge::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['positive' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3f4792426b7364bb3dac7370e7314380)): ?>
<?php $component = $__componentOriginal3f4792426b7364bb3dac7370e7314380; ?>
<?php unset($__componentOriginal3f4792426b7364bb3dac7370e7314380); ?>
<?php endif; ?>
                                        <?php break; ?>

                                        <?php default: ?>
                                    <?php endswitch; ?>
                                </td>
                                <td class="border-2  text-gray-700  px-3 py-1">
                                    <?php if($report->status != 'done'): ?>
                                        <?php if (isset($component)) { $__componentOriginal89c056f45462358edf1d624257ccfb3f = $component; } ?>
<?php $component = WireUi\View\Components\Dropdown::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dropdown'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(WireUi\View\Components\Dropdown::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

                                             <?php $__env->slot('trigger', null, []); ?> 

                                                <?php if (isset($component)) { $__componentOriginal53cf851b4d6af185b0b5e0467ca69b92 = $component; } ?>
<?php $component = WireUi\View\Components\Button::resolve(['label' => 'Options'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(WireUi\View\Components\Button::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['xs' => true,'dark' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal53cf851b4d6af185b0b5e0467ca69b92)): ?>
<?php $component = $__componentOriginal53cf851b4d6af185b0b5e0467ca69b92; ?>
<?php unset($__componentOriginal53cf851b4d6af185b0b5e0467ca69b92); ?>
<?php endif; ?>

                                             <?php $__env->endSlot(); ?>

                                            <?php if($report->status == 'pending'): ?>
                                                <?php if (isset($component)) { $__componentOriginal0dfa9bc3fdfc23d5909c03c26aad9268 = $component; } ?>
<?php $component = WireUi\View\Components\Dropdown\DropdownItem::resolve(['label' => 'Accept','icon' => 'thumb-up'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dropdown.item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(WireUi\View\Components\Dropdown\DropdownItem::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'acceptAppointment('.e($report->id).')']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0dfa9bc3fdfc23d5909c03c26aad9268)): ?>
<?php $component = $__componentOriginal0dfa9bc3fdfc23d5909c03c26aad9268; ?>
<?php unset($__componentOriginal0dfa9bc3fdfc23d5909c03c26aad9268); ?>
<?php endif; ?>
                                                <?php if (isset($component)) { $__componentOriginal0dfa9bc3fdfc23d5909c03c26aad9268 = $component; } ?>
<?php $component = WireUi\View\Components\Dropdown\DropdownItem::resolve(['label' => 'Decline','icon' => 'thumb-down'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dropdown.item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(WireUi\View\Components\Dropdown\DropdownItem::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'declineAppointment('.e($report->id).')']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0dfa9bc3fdfc23d5909c03c26aad9268)): ?>
<?php $component = $__componentOriginal0dfa9bc3fdfc23d5909c03c26aad9268; ?>
<?php unset($__componentOriginal0dfa9bc3fdfc23d5909c03c26aad9268); ?>
<?php endif; ?>
                                            <?php endif; ?>
                                            <?php if($report->status == 'accepted'): ?>
                                                <?php if (isset($component)) { $__componentOriginal0dfa9bc3fdfc23d5909c03c26aad9268 = $component; } ?>
<?php $component = WireUi\View\Components\Dropdown\DropdownItem::resolve(['label' => 'Done','icon' => 'check'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dropdown.item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(WireUi\View\Components\Dropdown\DropdownItem::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'doneAppointment('.e($report->id).')']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0dfa9bc3fdfc23d5909c03c26aad9268)): ?>
<?php $component = $__componentOriginal0dfa9bc3fdfc23d5909c03c26aad9268; ?>
<?php unset($__componentOriginal0dfa9bc3fdfc23d5909c03c26aad9268); ?>
<?php endif; ?>

                                                <?php if (isset($component)) { $__componentOriginal0dfa9bc3fdfc23d5909c03c26aad9268 = $component; } ?>
<?php $component = WireUi\View\Components\Dropdown\DropdownItem::resolve(['label' => 'Reschedule','icon' => 'clock'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dropdown.item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(WireUi\View\Components\Dropdown\DropdownItem::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'rescheduleAppointment('.e($report->id).')']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0dfa9bc3fdfc23d5909c03c26aad9268)): ?>
<?php $component = $__componentOriginal0dfa9bc3fdfc23d5909c03c26aad9268; ?>
<?php unset($__componentOriginal0dfa9bc3fdfc23d5909c03c26aad9268); ?>
<?php endif; ?>
                                            <?php endif; ?>


                                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal89c056f45462358edf1d624257ccfb3f)): ?>
<?php $component = $__componentOriginal89c056f45462358edf1d624257ccfb3f; ?>
<?php unset($__componentOriginal89c056f45462358edf1d624257ccfb3f); ?>
<?php endif; ?>
                                    <?php endif; ?>
                                </td>

                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="6" class="border-2 px-2 py-2">
                                        <span class="text-center  ">
                                            No data...
                                        </span>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>


        <?php if (isset($component)) { $__componentOriginal7ea8362733ae9e02c43079506217fb0f = $component; } ?>
<?php $component = WireUi\View\Components\Modal::resolve(['align' => 'center','maxWidth' => 'lg'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(WireUi\View\Components\Modal::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:model.defer' => 'reschedule_modal']); ?>

            <?php if (isset($component)) { $__componentOriginal526977d3da1dbf047bef54116d3416a0 = $component; } ?>
<?php $component = WireUi\View\Components\Card::resolve(['title' => 'RESCHEDULE'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(WireUi\View\Components\Card::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

                <div class="p-5">
                    <?php if (isset($component)) { $__componentOriginal2225aca2c40fa71fe239aabb14054f8e = $component; } ?>
<?php $component = WireUi\View\Components\DatetimePicker::resolve(['label' => 'Reschedule Date','withoutTime' => true] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('datetime-picker'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(WireUi\View\Components\DatetimePicker::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['placeholder' => ''.e(now()).'','wire:model' => 'reschedule_date']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2225aca2c40fa71fe239aabb14054f8e)): ?>
<?php $component = $__componentOriginal2225aca2c40fa71fe239aabb14054f8e; ?>
<?php unset($__componentOriginal2225aca2c40fa71fe239aabb14054f8e); ?>
<?php endif; ?>
                </div>



                 <?php $__env->slot('footer', null, []); ?> 

                    <div class="flex justify-end gap-x-4">

                        <?php if (isset($component)) { $__componentOriginal53cf851b4d6af185b0b5e0467ca69b92 = $component; } ?>
<?php $component = WireUi\View\Components\Button::resolve(['flat' => true,'label' => 'Cancel'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(WireUi\View\Components\Button::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['x-on:click' => 'close']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal53cf851b4d6af185b0b5e0467ca69b92)): ?>
<?php $component = $__componentOriginal53cf851b4d6af185b0b5e0467ca69b92; ?>
<?php unset($__componentOriginal53cf851b4d6af185b0b5e0467ca69b92); ?>
<?php endif; ?>

                        <?php if (isset($component)) { $__componentOriginal53cf851b4d6af185b0b5e0467ca69b92 = $component; } ?>
<?php $component = WireUi\View\Components\Button::resolve(['label' => 'Submit','spinner' => 'submitReschedule'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(WireUi\View\Components\Button::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'submitReschedule','dark' => true,'class' => 'font-bold']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal53cf851b4d6af185b0b5e0467ca69b92)): ?>
<?php $component = $__componentOriginal53cf851b4d6af185b0b5e0467ca69b92; ?>
<?php unset($__componentOriginal53cf851b4d6af185b0b5e0467ca69b92); ?>
<?php endif; ?>

                    </div>

                 <?php $__env->endSlot(); ?>

             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal526977d3da1dbf047bef54116d3416a0)): ?>
<?php $component = $__componentOriginal526977d3da1dbf047bef54116d3416a0; ?>
<?php unset($__componentOriginal526977d3da1dbf047bef54116d3416a0); ?>
<?php endif; ?>

         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7ea8362733ae9e02c43079506217fb0f)): ?>
<?php $component = $__componentOriginal7ea8362733ae9e02c43079506217fb0f; ?>
<?php unset($__componentOriginal7ea8362733ae9e02c43079506217fb0f); ?>
<?php endif; ?>
    </div>
<?php /**PATH C:\xampp\htdocs\SIDELINE PROJECTS\MMG\resources\views/livewire/doctor/doctor-appointment.blade.php ENDPATH**/ ?>