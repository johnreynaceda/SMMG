@section('title', 'PATIENTS')
<x-admin-layout>
    <livewire:admin.admin-patient />
</x-admin-layout>
