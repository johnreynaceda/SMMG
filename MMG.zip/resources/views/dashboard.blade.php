<x-app-layout>
    <livewire:patient-dashboard />
</x-app-layout>
