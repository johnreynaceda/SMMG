<x-app-layout>
    <div class="py-20 ">

        <div class="mx-auto max-w-7xl relative">
            <livewire:patient.get-appointment />

        </div>
    </div>
</x-app-layout>
