@section('title', 'APPOINTMENTS')
<x-admin-layout>
    <livewire:admin.admin-appointment />
</x-admin-layout>
