@section('title', 'MEDTECH ')
<x-admin-layout>
    <livewire:admin.medtech />
</x-admin-layout>
