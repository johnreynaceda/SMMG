@section('title', 'DASHBOARD')
<x-admin-layout>
    <livewire:admin.admin-dashboard />
</x-admin-layout>
