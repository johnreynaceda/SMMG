@section('title', 'NURSES')
<x-admin-layout>
    <livewire:admin.nurses />
</x-admin-layout>
