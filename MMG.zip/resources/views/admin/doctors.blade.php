@section('title', 'DOCTORS')
<x-admin-layout>
    <livewire:admin.doctor />
</x-admin-layout>
