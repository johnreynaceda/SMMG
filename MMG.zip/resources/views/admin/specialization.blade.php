@section('title', 'SPECIALIZATION')
<x-admin-layout>
    <livewire:admin.specialization-list />
</x-admin-layout>
