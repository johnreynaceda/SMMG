@section('title', 'DASHBOARD')
<x-doctor-layout>
    <div>
        <livewire:doctor.doctor-dashboard />
    </div>
</x-doctor-layout>
