@section('title', 'NURSE DASHBOARD')
<x-nurse-layout>
    <livewire:nurse.nurse-dashboard />
</x-nurse-layout>
