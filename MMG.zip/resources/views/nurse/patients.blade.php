@section('title', 'PATIENTS')
<x-nurse-layout>
    <livewire:nurse.patient-list />
</x-nurse-layout>
