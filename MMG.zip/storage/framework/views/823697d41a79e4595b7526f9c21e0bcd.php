<button wire:loading.attr="disabled" wire:loading.class="!cursor-wait" type="button" class="outline-none inline-flex justify-center items-center group transition-all ease-in duration-150 focus:ring-2 focus:ring-offset-2 hover:shadow-sm disabled:opacity-80 disabled:cursor-not-allowed rounded gap-x-1 text-xs px-2.5 py-1.5     border text-slate-500 hover:bg-slate-100 ring-slate-200
    dark:ring-slate-600 dark:border-slate-500 dark:hover:bg-slate-700
    dark:ring-offset-slate-800 dark:text-slate-400 text-secondary-400 dark:border-0 dark:hover:bg-secondary-700 uppercase" x-on:click="selectMonth(index)" x-text="monthName">
    
    

    
    </button>
<?php /**PATH C:\xampp\htdocs\SIDELINE PROJECTS\MMG\storage\framework\views/9c590998e7d2dbc5ba5680131850c2af.blade.php ENDPATH**/ ?>