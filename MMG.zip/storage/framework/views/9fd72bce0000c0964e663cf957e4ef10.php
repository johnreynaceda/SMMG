

<div x-data>
    <div class="flex justify-between items-end">
        <div class="flex space-x-3 items-center">
            <?php if (isset($component)) { $__componentOriginal2225aca2c40fa71fe239aabb14054f8e = $component; } ?>
<?php $component = WireUi\View\Components\DatetimePicker::resolve(['label' => 'Date From','withoutTime' => true] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('datetime-picker'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(WireUi\View\Components\DatetimePicker::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['placeholder' => ''.e(now()).'','wire:model' => 'created_from']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2225aca2c40fa71fe239aabb14054f8e)): ?>
<?php $component = $__componentOriginal2225aca2c40fa71fe239aabb14054f8e; ?>
<?php unset($__componentOriginal2225aca2c40fa71fe239aabb14054f8e); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal2225aca2c40fa71fe239aabb14054f8e = $component; } ?>
<?php $component = WireUi\View\Components\DatetimePicker::resolve(['label' => 'Date To','withoutTime' => true] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('datetime-picker'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(WireUi\View\Components\DatetimePicker::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['placeholder' => ''.e(now()).'','wire:model' => 'created_until']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2225aca2c40fa71fe239aabb14054f8e)): ?>
<?php $component = $__componentOriginal2225aca2c40fa71fe239aabb14054f8e; ?>
<?php unset($__componentOriginal2225aca2c40fa71fe239aabb14054f8e); ?>
<?php endif; ?>
        </div>
        <div>
            <?php if (isset($component)) { $__componentOriginal53cf851b4d6af185b0b5e0467ca69b92 = $component; } ?>
<?php $component = WireUi\View\Components\Button::resolve(['label' => 'PRINT','icon' => 'printer'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(WireUi\View\Components\Button::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'font-bold','@click' => 'printOut($refs.printContainer.outerHTML);','dark' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal53cf851b4d6af185b0b5e0467ca69b92)): ?>
<?php $component = $__componentOriginal53cf851b4d6af185b0b5e0467ca69b92; ?>
<?php unset($__componentOriginal53cf851b4d6af185b0b5e0467ca69b92); ?>
<?php endif; ?>
        </div>

    </div>
    <div class="mt-5">
        <div x-ref="printContainer" class="bg-white p-5 rounded-xl">
            <div class="flex space-x-3 items-center">
                <div>
                    <img src="<?php echo e(asset('images/logo.png')); ?>" class="h-12" alt="">
                </div>
                <div>
                    <h1 class="text-xl font-bold text-gray-700">MMG - BULAN</h1>
                    <h1 class="text-md  leading-3 font-bold uppercase text-gray-500">Appointments List</h1>
                </div>
            </div>
            <div class="mt-10">
                <table id="example" class="table-auto" style="width:100%">
                    <thead class="font-normal">
                        <tr>
                            <th class="border-2  text-left px-2 text-sm font-bold text-gray-700 py-2">PATIENT NAME
                            </th>
                            <th class="border-2  text-left px-2 text-sm font-bold text-gray-700 py-2">DOCTOR NAME
                            </th>
                            <th class="border-2  text-left px-2 text-sm font-bold text-gray-700 py-2">SPECIALIZATION
                            </th>
                            <th class="border-2  text-left px-2 text-sm font-bold text-gray-700 py-2">EMAIL</th>
                            <th class="border-2  text-left px-2 text-sm font-bold text-gray-700 py-2">PHONE NUMBER
                            </th>
                            <th class="border-2  text-left px-2 text-sm font-bold text-gray-700 py-2">DATE OF
                                APPOINTMENT
                            </th>


                        </tr>
                    </thead>
                    <tbody class="">
                        <?php $__empty_1 = true; $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="border-2 uppercase text-gray-700  px-3 py-1">
                                    <?php echo e($report->user->name); ?>

                                </td>
                                <td class="border-2 uppercase text-gray-700  px-3 py-1">
                                    <?php echo e($report->doctor->user->name); ?>

                                </td>
                                <td class="border-2  text-gray-700  px-3 py-1">
                                    <?php $__currentLoopData = $report->doctor->doctor_specializations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo e($value->specialization->name); ?>

                                        <?php if(!$loop->last): ?>
                                            /
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                                <td class="border-2  text-gray-700  px-3 py-1">
                                    <?php echo e($report->doctor->user->email); ?>

                                </td>
                                <td class="border-2  text-gray-700  px-3 py-1">
                                    <?php echo e($report->doctor->user->phone_number); ?>

                                </td>
                                <td class="border-2  text-gray-700  px-3 py-1">
                                    <?php echo e(\Carbon\Carbon::parse($report->appointment_date)->format('F d, Y')); ?>

                                </td>

                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="6" class="border-2 px-2 py-2">
                                    <span class="text-center  ">
                                        No data...
                                    </span>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\SIDELINE PROJECTS\MMG\resources\views/livewire/doctor/doctor-appointment.blade.php ENDPATH**/ ?>